# SOM — informe para armar el sitio del producto

> **Instrucción para vos, Claude Code:** este documento es sólo información.
> **No escribas una línea de código hasta el final.** Cuando termines de
> leerlo, andá directo a la sección **"Lo que tenés que preguntar"** y hacé
> esas preguntas. Esperá las respuestas antes de proponer nada.

---

## 1. Qué es SOM

**SOM — Sistema de Organización de Muestras.** Un sistema de gestión para
**laboratorios de microbiología de alimentos**. Cubre el circuito completo:
desde que entra la muestra al laboratorio hasta que sale el Informe de Ensayo
firmado.

No es un SaaS. **Se instala en un servidor del propio laboratorio y funciona
sin conexión a internet.** Las computadoras del laboratorio entran por la red
interna. No hay nube, no hay cuenta, no hay mensualidad por usuario.

Está hecho en PostgreSQL + Node + React, pero eso no le importa a quien va a
leer la página.

---

## 2. A quién le habla la página

Dueños y directores técnicos de **laboratorios chicos** de microbiología de
alimentos, en Uruguay.

**Cómo trabajan hoy, que es el problema que SOM resuelve:** la muestra se
anota en un cuaderno, los resultados en una planilla, el informe se arma en un
procesador de texto y el conteo del mes para facturar se hace contando a mano.
Cada dato se escribe tres o cuatro veces y cada vez puede salir distinto.
Cuando llega una auditoría, reconstruir qué pasó con una muestra de hace ocho
meses lleva una tarde.

No tienen un problema de análisis. Tienen un problema de papeles.

**Idioma: español rioplatense, con voseo** ("escribime", "vas a ver", "tenés").
Nada de "usted", nada de español neutro.

---

## 3. El circuito, que es la columna vertebral del producto

La aplicación lo numera así en su propio menú, no es un invento de la página:

**Etapa 1 — Ingreso de muestra.** Se elige el cliente, se describe la muestra
y se marcan los ensayos. **El número de muestra lo pone el sistema**, no se
lleva más a mano. Los ensayos salen del catálogo del laboratorio, con sus
parámetros y sus metodologías.

**Etapa 2 — Carga de resultados.** Cada análisis pendiente aparece con sus
parámetros ya cargados y su valor de referencia al lado. El analista no tipea
de cero: completa lo que midió y guarda. La metodología queda registrada junto
al resultado.

**Etapa 3 — Reporte de análisis.** Los análisis terminados de un mismo cliente
se agrupan en un informe y se publican. El sistema lleva la numeración y las
cuatro fechas (muestreo, recepción, análisis, emisión), y registra qué se
imprimió y cuándo.

**El entregable: el Informe de Ensayo.** Sale sobre la hoja membretada del
laboratorio, con su logo, dirección, número de acreditación y la firma del
responsable. **Si el ensayo usa una metodología acreditada, sale con el sello;
si no, sale sin él — y esa decisión la toma el sistema a partir del catálogo,
no la persona que imprime.**

> Esto último es lo más importante de todo el producto. Un laboratorio no
> compra un sistema: compra que el informe salga bien. Si la página tiene un
> solo momento fuerte, es este.

---

## 4. Lo demás que hace

- **Fichas de clientes** con datos de contacto e historial completo de todo lo
  que se les analizó.
- **Conteo mensual**: cuántos informes y análisis se le hicieron a cada cliente
  en el mes. Es el dato para facturar, sin contarlo a mano.
- **Catálogo propio** de ensayos, parámetros, metodologías y valores de
  referencia. El catálogo de un laboratorio es suyo; no se reusa el de otro.
- **Usuarios, roles y firmas**: cada analista con su usuario y su firma
  escaneada. El administrador decide quién ve qué.
- **Respaldos automáticos** programados, más uno a demanda. Quedan en el disco
  que el laboratorio elija.

---

## 5. Los tres argumentos de venta

1. **Los datos no salen del laboratorio.** Los clientes, sus resultados y sus
   informes quedan en un servidor del laboratorio. No hay una copia en el
   servidor de otro.
2. **Se cae internet y se sigue trabajando.** El sistema no depende de la
   conexión.
3. **Se carga una vez.** Lo que se escribe al ingresar la muestra no se vuelve
   a tipear nunca más: viaja hasta el informe.

---

## 6. Qué tiene que lograr la página

**Que el laboratorio escriba.** Es el único objetivo. No hay venta online, no
hay demo público, no hay registro.

- **Sin precios.** Todavía no están definidos y no van a la página.
- **Hosting:** dominio propio (todavía sin comprar). La página tiene que
  funcionar como archivos sueltos subidos a cualquier lado, sin depender de
  ningún servicio.
- **Contacto:** WhatsApp y correo. **Los datos reales los va a poner el dueño**
  — dejalos como marcador bien visible y avisale dónde están.

---

## 7. Material disponible

En la carpeta del proyecto:

| Archivo | Qué muestra |
|---|---|
| `img/panel.jpg` | El panel de control: pendientes, listos para informe, informes del día, ensayos más solicitados, gráfico de 14 días |
| `img/ingreso.jpg` | Alta de una muestra + listado de muestras recientes |
| `img/resultados.jpg` | Carga de resultados: análisis pendientes a la izquierda, formulario con parámetros y metodología a la derecha |
| `img/reporte.jpg` | Listado de informes publicados |
| `img/informe.jpg` | **El Informe de Ensayo terminado**, con membrete y sello |
| `img/clientes.jpg` | Ficha de cliente |
| `img/conteo.jpg` | Conteo mensual por cliente |
| `img/login.jpg` | Pantalla de ingreso |
| `img/emblema.png` | El emblema circular de SOM, 512×512 con transparencia |
| `video/recorrido.mp4` | 1:09, 1080p. Arranca con la animación de marca y después recorre el sistema |

Todas las capturas y el video son de **una instalación de demostración con
datos inventados**. Ningún dato corresponde a un laboratorio, empresa o persona
real — y **la página tiene que decirlo en algún lado**, discretamente.

---

## 8. Límites que no se negocian

- **No inventes funciones.** Si no está en este documento, el sistema no lo
  hace. Nada de "integraciones", "app móvil", "reportes con IA".
- **No inventes clientes ni testimonios.** El sistema está funcionando en un
  laboratorio real, pero **el dueño todavía no autorizó nombrarlo ni
  aludirlo**. Preguntale antes de escribir una sola palabra sobre eso.
- **No inventes números** (años de desarrollo, cantidad de muestras, tiempo
  ahorrado). Si querés usar alguno, preguntá.
- **Nada de datos reales** en capturas o ejemplos. Usá el material de la lista.

---

## 9. La vara técnica

- Página estática. Sin framework si no hace falta.
- Tiene que andar en **claro y en oscuro**, y en celular sin desbordarse para
  el costado.
- `<meta charset="utf-8">` desde el principio: el texto va con acentos y sin
  eso salen rotos.
- Si usás tipografías de Google, dejá una pila de respaldo real.
- Las imágenes de abajo del pliegue con `loading="lazy"`.
- Foco de teclado visible, y respetar `prefers-reduced-motion`.

---

## Lo que tenés que preguntar

Terminaste de leer. **No propongas nada todavía.** Hacé estas preguntas, de a
poco, y esperá las respuestas:

**Sobre la estructura**
1. ¿Qué secciones querés y en qué orden? (Mi sugerencia como punto de partida,
   para que la aceptes o la rompas: portada → el problema → las tres etapas con
   capturas → el Informe de Ensayo en grande → por qué sin internet → qué
   incluye → contacto. El video puede ir arriba de todo o después del problema.)
2. ¿Una sola página larga, o varias?
3. ¿Dónde querés el video, y arranca solo o con play?

**Sobre el diseño**
4. ¿Qué paleta? Pasame los colores si ya los tenés. Si no: el sistema usa verde
   agua (#0d7a6f) sobre azul tinta muy oscuro (#03081a), y el emblema es azul.
   ¿Seguimos esa línea o la página va por otro lado?
5. ¿Qué registro visual buscás? No es lo mismo un folleto institucional serio,
   una landing moderna de software, o algo más sobrio tipo documento técnico.
   ¿Tenés alguna página que te guste como referencia?
6. ¿Tipografías? ¿Alguna en particular, o propongo?
7. ¿Cuánto movimiento? ¿Animaciones al hacer scroll, o quieta y sobria?
8. ¿Las capturas van enteras, recortadas, con marco de navegador, en ángulo?

**Sobre el contenido**
9. ¿Cómo querés que te contacten: WhatsApp, correo, formulario, o varios?
10. ¿La página lleva tu nombre y tu cara, o se presenta sólo como producto?
11. ¿Qué hacemos con lo del laboratorio que ya lo usa? ¿Se puede mencionar sin
    nombrarlo, se nombra, o no se toca?

Cuando tengas las respuestas, mostrame la estructura y la paleta escritas antes
de escribir código, para que las confirme.
